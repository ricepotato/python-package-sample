class InfraMod(object):
    def __init__(self):
        pass

    def exist(self, hash):
        if hash == "some_hash":
            return True
        else:
            return False
